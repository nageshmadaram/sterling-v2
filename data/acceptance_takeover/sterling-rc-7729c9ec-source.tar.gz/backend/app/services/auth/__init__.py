"""Authentication services (user store)."""
