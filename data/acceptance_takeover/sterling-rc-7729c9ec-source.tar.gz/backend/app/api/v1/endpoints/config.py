"""Indian-market strategy configuration endpoints."""
from typing import Any, Literal, Optional

from fastapi import APIRouter, Body, Depends, HTTPException
from pydantic import BaseModel, ConfigDict, Field, model_validator

from app.core.auth import UserContext, get_current_user

router = APIRouter(prefix="/config", tags=["config"])




# ------------------------------------------------------------------ Gamma Move

@router.get("/gamma-move")
async def get_gamma_move_config(user: UserContext = Depends(get_current_user)) -> dict:
    """Gamma-Unwind client config; defaults are published from the engine itself."""
    from app.engines.gamma_move.config import (
        CLIENT_TOP_N_OI, DIRECTION_MODES, STOP_MODES, GammaMoveConfig,
    )
    from app.services.gamma_move import (
        descriptor, get_config, listed_stock_underlyings, nfo_dump,
    )
    uid = getattr(user, "user_id", None) or getattr(user, "uid", None) or "default"
    cfg = get_config(uid)
    try:
        listed_stocks = listed_stock_underlyings(await nfo_dump(uid))
    except Exception:
        # Config remains readable when broker metadata is temporarily down; an
        # empty picker is more truthful than falling back to a different universe.
        listed_stocks = []
    return {
        "strategy": {**descriptor(), "enabled": cfg.enabled},
        "config": cfg.as_dict(),
        "defaults": GammaMoveConfig().as_dict(),
        "vocabularies": {
            "stop_mode": sorted(STOP_MODES),
            "v1_direction_mode": sorted(DIRECTION_MODES),
            "scan_stocks": listed_stocks,
        },
        "client_effective": {
            "top_n_oi": CLIENT_TOP_N_OI,
            "base_tf_min": 1,
            "signal_tf_min": 5,
            "display_tf_min": 15,
        },
        "warnings": [
            "Client edition 0.8.6 selects top 2 contracts (HOI-1 and HOI-2) per stock.",
            "The supplied reference project is signal-only. Sterling execution is a separate adapter and only ENTRY tier may execute.",
            "Live swing ENTRY is fail-closed before T1 because the exact D68 underlying daily-close stop is not a broker premium stop.",
        ],
    }


@router.put("/gamma-move")
async def update_gamma_move_config(body: dict = Body(...),
                                   user: UserContext = Depends(get_current_user)) -> dict:
    """Apply a partial config change.

    Only the keys present are changed. Unknown keys are refused rather than
    ignored: a silently dropped setting is worse than a 422, because the UI has
    no way to tell it did not take.
    """
    from app.services.gamma_move import set_config
    values = {k: v for k, v in dict(body).items() if v is not None}
    if not values:
        raise HTTPException(status_code=422, detail="no settings to change")
    uid = getattr(user, "user_id", None) or getattr(user, "uid", None) or "default"
    try:
        cfg = set_config(values, uid=uid)
    except (ValueError, TypeError) as exc:
        raise HTTPException(status_code=422, detail=str(exc)) from exc
    return {"config": cfg.as_dict()}


@router.get("/gamma-move/history")
async def gamma_move_history(
    user: UserContext = Depends(get_current_user),
    days: int = 60,
    limit: int = 500,
) -> dict:
    """Recent persisted Gamma-Unwind E1 ledger across trading days."""
    uid = getattr(user, "user_id", None) or getattr(user, "uid", None)
    if not uid:
        raise HTTPException(status_code=401, detail="authenticated user is required")
    from app.services import gamma_move_history as history
    try:
        return history.signal_ledger(uid, days=days, limit=limit)
    except (TypeError, ValueError) as exc:
        raise HTTPException(status_code=422, detail=str(exc)) from exc
    except Exception as exc:
        raise HTTPException(
            status_code=502,
            detail=f"Gamma-Unwind history failed: {exc}",
        ) from exc


@router.get("/gamma-move/snapshot")
async def gamma_move_snapshot(
    user: UserContext = Depends(get_current_user),
    day: Optional[str] = None,
) -> dict:
    """Live board or one exact recorded trading-day view."""
    uid = getattr(user, "user_id", None) or getattr(user, "uid", None)
    if not uid:
        raise HTTPException(status_code=401, detail="authenticated user is required")
    from app.services.simulation import simulation_runner
    if simulation_runner.has_session_view and getattr(simulation_runner, '_uid', None) == uid:
        return simulation_runner.get_gamma_snapshot()
    from app.services.gamma_move import snapshot
    try:
        return await snapshot(uid, day=day)
    except ValueError as exc:
        raise HTTPException(status_code=422, detail=f"invalid day: {exc}") from exc
    except Exception as exc:
        raise HTTPException(status_code=502,
                            detail=f"Gamma-Unwind snapshot failed: {exc}") from exc


@router.post("/gamma-move/history/replay")
async def gamma_move_history_replay(
    body: dict = Body(...),
    user: UserContext = Depends(get_current_user),
) -> dict:
    """Load one past trading day from the finest broker history available."""
    from datetime import date as _date

    uid = getattr(user, "user_id", None) or getattr(user, "uid", None)
    if not uid:
        raise HTTPException(status_code=401, detail="authenticated user is required")
    raw_day = str(dict(body).get("day") or "").strip()
    if not raw_day:
        raise HTTPException(status_code=422, detail="day is required")
    try:
        selected = _date.fromisoformat(raw_day)
    except ValueError as exc:
        raise HTTPException(status_code=422, detail="day must be YYYY-MM-DD") from exc

    from app.services.gamma_move import get_config, ist_today, snapshot
    today = ist_today()
    if selected >= today:
        raise HTTPException(
            status_code=422,
            detail="historical signal loading requires a completed day before today",
        )

    force = bool(dict(body).get("force"))
    from app.services import gamma_move_history
    existing = gamma_move_history.read_day(uid, selected)
    if (
        existing is not None
        and existing.get("source") == "live_recorded"
    ):
        return await snapshot(uid, day=selected)
    if (
        existing is not None
        and existing.get("source") == "historical_replay"
        and bool((existing.get("replay") or {}).get("complete"))
        and not force
    ):
        return await snapshot(uid, day=selected)

    from app.services.gamma_move_historical import replay_day
    try:
        result = await replay_day(uid, selected, get_config(uid))
    except Exception as exc:
        raise HTTPException(
            status_code=502,
            detail=f"Gamma-Unwind historical signal load failed: {exc}",
        ) from exc
    gamma_move_history.record_replay(uid, result)
    return await snapshot(uid, day=selected)


@router.post("/gamma-move/scan")
async def gamma_move_scan(user: UserContext = Depends(get_current_user)) -> dict:
    """Run one on-demand levels -> strikes -> trigger pass."""
    uid = getattr(user, "user_id", None) or getattr(user, "uid", None)
    if not uid:
        raise HTTPException(status_code=401, detail="authenticated user is required")
    from app.services.simulation import simulation_runner
    if simulation_runner.owns_session(uid):
        raise HTTPException(status_code=409,
                            detail="Market replay is controlling this board; live scan is disabled.")
    from app.services.gamma_move_runner import scan_once
    try:
        return await scan_once(uid)
    except Exception as exc:
        raise HTTPException(status_code=502,
                            detail=f"Gamma-Unwind scan failed: {exc}") from exc


@router.post("/gamma-move/arm")
async def gamma_move_arm(body: dict = Body(...),
                         user: UserContext = Depends(get_current_user)) -> dict:
    """Enter one armed signal by id."""
    uid = getattr(user, "user_id", None) or getattr(user, "uid", None)
    if not uid:
        raise HTTPException(status_code=401, detail="authenticated user is required")
    from app.services.simulation import simulation_runner
    if simulation_runner.owns_session(uid):
        raise HTTPException(status_code=409,
                            detail="Market replay is controlling this board; live entry is disabled.")
    signal_id = str(dict(body).get("signal_id") or "").strip()
    if not signal_id:
        raise HTTPException(status_code=422, detail="signal_id is required")
    from app.services.gamma_move_runner import arm
    return await arm(uid, signal_id)


@router.post("/gamma-move/adopt")
async def gamma_move_adopt(body: dict = Body(...),
                           user: UserContext = Depends(get_current_user)) -> dict:
    """Take responsibility for a position this engine did not open."""
    uid = getattr(user, "user_id", None) or getattr(user, "uid", None)
    if not uid:
        raise HTTPException(status_code=401, detail="authenticated user is required")
    data = dict(body)
    symbol = str(data.get("symbol") or "").strip()
    try:
        quantity = int(data.get("quantity") or 0)
        entry_price = float(data.get("entry_price") or 0)
    except (TypeError, ValueError) as exc:
        raise HTTPException(status_code=422, detail="quantity and entry_price "
                                                    "must be numbers") from exc
    if not symbol or quantity <= 0 or entry_price <= 0:
        raise HTTPException(status_code=422,
                            detail="symbol, a positive quantity and entry_price are required")
    from app.services.simulation import simulation_runner
    if simulation_runner.owns_session(uid):
        raise HTTPException(status_code=409,
                            detail="Market replay is controlling this board; live adoption is disabled.")
    from app.services.gamma_move_runner import adopt
    return await adopt(uid, symbol, quantity, entry_price)


@router.post("/gamma-move/simulate")
async def gamma_move_simulate(
    body: dict = Body(...),
    user: UserContext = Depends(get_current_user),
) -> dict:
    del body, user
    raise HTTPException(
        status_code=409,
        detail=(
            "Gamma-Unwind client E1 is tick-driven. Historical 5-minute candles "
            "cannot reproduce the live intrabar breakout, so the old Gamma Move "
            "simulator has been retired rather than returning false parity."
        ),
    )


@router.post("/gamma-move/simulate/stop")
async def gamma_move_simulate_stop(
    user: UserContext = Depends(get_current_user),
) -> dict:
    del user
    return {"ok": False, "message": "no Gamma-Unwind simulation is running"}



# ---------------------------------------------------------------- Adaptive Edge

@router.get("/adaptive-edge")
async def get_adaptive_edge_config(
    user: UserContext = Depends(get_current_user),
) -> dict:
    """Current config plus the engine's defaults, vocabularies and provenance.

    Defaults and enums are published rather than mirrored in the client, so the
    UI cannot drift from the engine — the recurring bug class here is a UI that
    claims backend behaviour the backend does not honour.

    ``calibration`` is published for the opposite reason to Gamma Move's. There
    every threshold was measured; here none were, and ``calibrated_fields`` is
    empty. The UI needs both facts to mark each number uncalibrated rather than
    rendering a bare figure an operator may reasonably read as meaningful.
    """
    from app.engines.adaptive_edge.config import (
        DATA_SOURCES, DECISION_TIMEFRAMES, EXIT_POLICIES, SIZING_MODES,
        STOP_MODES, STRATEGY_VERSIONS, AdaptiveEdgeConfig,
    )
    from app.engines.option_contracts import EXPIRY_SELECTIONS, EXPIRY_SERIES
    from app.services.kite_engine.stock_registry import HIGH_LIQUIDITY_STOCK_NAMES
    from app.services.adaptive_edge import descriptor, get_config
    uid = getattr(user, "user_id", None) or getattr(user, "uid", None) or "default"
    cfg = get_config(uid)
    return {
        "strategy": {**descriptor(), "enabled": cfg.enabled},
        "config": cfg.as_dict(),
        "defaults": AdaptiveEdgeConfig().as_dict(),
        "vocabularies": {
            "strategy_version": sorted(STRATEGY_VERSIONS),
            "decision_timeframe": sorted(DECISION_TIMEFRAMES),
            "data_source": sorted(DATA_SOURCES),
            "exit_policy": sorted(EXIT_POLICIES),
            "sizing_mode": sorted(SIZING_MODES),
            "stop_mode": sorted(STOP_MODES),
            "expiry_selection": sorted(EXPIRY_SELECTIONS),
            "expiry_series": sorted(EXPIRY_SERIES),
            "stocks": sorted(HIGH_LIQUIDITY_STOCK_NAMES),
        },
        "warnings": cfg.warnings(),
    }


@router.put("/adaptive-edge")
async def update_adaptive_edge_config(
    body: dict = Body(...),
    user: UserContext = Depends(get_current_user),
) -> dict:
    """Apply a partial config change.

    Only the keys present are changed. Unknown keys are refused rather than
    ignored: a silently dropped setting is worse than a 422, because the UI has
    no way to tell it did not take.
    """
    from app.services.adaptive_edge import set_config
    values = {k: v for k, v in dict(body).items() if v is not None}
    if not values:
        raise HTTPException(status_code=422, detail="no settings to change")
    uid = getattr(user, "user_id", None) or getattr(user, "uid", None) or "default"
    try:
        cfg = set_config(values, uid=uid)
        try:
            from app.api.v1.endpoints.adaptive_edge import clear_bridged_cache
            clear_bridged_cache()
        except Exception:
            pass
    except (ValueError, TypeError) as exc:
        raise HTTPException(status_code=422, detail=str(exc)) from exc
    return {"config": cfg.as_dict()}


@router.get("/adaptive-edge/snapshot")
async def adaptive_edge_snapshot(user: UserContext = Depends(get_current_user)) -> dict:
    """Config, what the scan found, and every reason nothing is armed."""
    uid = getattr(user, "user_id", None) or getattr(user, "uid", None)
    if not uid:
        raise HTTPException(status_code=401, detail="authenticated user is required")
    from app.services.simulation import simulation_runner
    if simulation_runner.owns_session(uid):
        return simulation_runner.get_adaptive_edge_snapshot()

    from app.services.adaptive_edge import snapshot
    try:
        return await snapshot(uid)
    except Exception as exc:
        raise HTTPException(status_code=502,
                            detail=f"Adaptive Edge snapshot failed: {exc}") from exc




def _archived_entry_surface(strategy: str, uid: str) -> None:
    from app.services.archived_strategies import enabled
    if not enabled(uid, strategy):
        raise HTTPException(410, f"{strategy} is archived and disabled. Enable it in Settings → Archived. Existing position management remains available.")

class ArchivedStrategyUpdate(BaseModel):
    model_config = ConfigDict(extra="forbid")
    enabled: bool = Field(strict=True)

@router.get("/archived-strategies")
async def archived_strategies(user: UserContext = Depends(get_current_user)) -> dict:
    from app.services.archived_strategies import list_for
    from app.services.db import ControlPlaneUnavailableError
    try:
        return {"strategies": list_for(_intraday_uid(user))}
    except ControlPlaneUnavailableError as exc:
        raise HTTPException(503, "Strategy settings storage unavailable") from exc

@router.put("/archived-strategies/{strategy}")
async def update_archived_strategy(strategy: str, body: ArchivedStrategyUpdate,
                                   user: UserContext = Depends(get_current_user)) -> dict:
    from app.services.archived_strategies import set_enabled
    from app.services.db import ControlPlaneUnavailableError
    try:
        uid = _intraday_uid(user)
        result = set_enabled(uid, strategy, body.enabled)
        if strategy == "navigator" and not body.enabled:
            from app.services.navigator.runtime import stop_user_samplers
            await stop_user_samplers(uid)
        return {"strategies": result}
    except ValueError as exc:
        raise HTTPException(422, str(exc)) from exc
    except ControlPlaneUnavailableError as exc:
        raise HTTPException(503, "Strategy settings storage unavailable") from exc

@router.post("/adaptive-edge/scan")
async def adaptive_edge_scan(user: UserContext = Depends(get_current_user)) -> dict:
    uid = _intraday_uid(user)
    _archived_entry_surface("adaptive_edge", uid)
    from app.services.adaptive_edge_runner import scan_once
    return await scan_once(uid)

@router.post("/adaptive-edge/arm")
async def adaptive_edge_arm(body: dict = Body(...), user: UserContext = Depends(get_current_user)) -> dict:
    uid = _intraday_uid(user)
    _archived_entry_surface("adaptive_edge", uid)
    signal_id = str(body.get("signal_id") or "").strip()
    if not signal_id:
        raise HTTPException(422, "signal_id is required")
    from app.services.adaptive_edge_runner import arm
    return await arm(uid, signal_id)


@router.post("/adaptive-edge/adopt")
async def adaptive_edge_adopt(body: dict = Body(...),
                              user: UserContext = Depends(get_current_user)) -> dict:
    """Take responsibility for a position this engine did not open.

    Protection is placed as part of adopting. A hand-placed position the engine
    is managing but has not protected is the worst of both worlds.
    """
    uid = getattr(user, "user_id", None) or getattr(user, "uid", None)
    if not uid:
        raise HTTPException(status_code=401, detail="authenticated user is required")
    data = dict(body)
    symbol = str(data.get("symbol") or "").strip()
    try:
        quantity = int(data.get("quantity") or 0)
        entry_price = float(data.get("entry_price") or 0)
    except (TypeError, ValueError) as exc:
        raise HTTPException(status_code=422,
                            detail="quantity and entry_price must be numbers") from exc
    if not symbol or quantity <= 0 or entry_price <= 0:
        raise HTTPException(status_code=422,
                            detail="symbol, a positive quantity and entry_price are required")
    from app.services.adaptive_edge_runner import adopt
    return await adopt(uid, symbol, quantity, entry_price)


@router.post("/adaptive-edge/square-off")
async def adaptive_edge_square_off(user: UserContext = Depends(get_current_user)) -> dict:
    """Flatten everything this engine holds, now.

    Deliberately available whatever the manual/auto setting says: auto gates
    opening, and an operator must always be able to close.
    """
    uid = getattr(user, "user_id", None) or getattr(user, "uid", None)
    if not uid:
        raise HTTPException(status_code=401, detail="authenticated user is required")
    from app.services.adaptive_edge_runner import square_off_all
    return await square_off_all(uid)


@router.post("/adaptive-edge/reconcile")
async def adaptive_edge_reconcile(user: UserContext = Depends(get_current_user)) -> dict:
    """Re-sync against the broker: close what it no longer holds, re-protect the rest."""
    uid = getattr(user, "user_id", None) or getattr(user, "uid", None)
    if not uid:
        raise HTTPException(status_code=401, detail="authenticated user is required")
    from app.services.adaptive_edge_runner import reconcile
    return await reconcile(uid)


@router.get("/adaptive-edge/positions")
async def adaptive_edge_positions(user: UserContext = Depends(get_current_user)) -> dict:
    """What this engine is holding, and whether each position has a broker stop."""
    uid = getattr(user, "user_id", None) or getattr(user, "uid", None)
    if not uid:
        raise HTTPException(status_code=401, detail="authenticated user is required")
    from app.services.adaptive_edge_positions import load
    from app.services.adaptive_edge_runner import realised_pnl_today
    rows = []
    for pos in load(uid).values():
        rows.append({
            "symbol": pos.symbol, "underlying": pos.underlying, "type": pos.direction,
            "quantity": pos.quantity, "entry": pos.entry_price, "stop": pos.stop_price,
            "target": pos.target_price, "peak": pos.peak_price, "state": pos.state,
            "open": pos.is_open, "exit_price": pos.exit_price,
            "exit_reason": pos.exit_reason,
            # "Has a trigger id" is not enough: a failed resize can leave
            # an older GTT protecting fewer units or a stale stop.
            "broker_stop": bool(
                pos.gtt_id
                and int(pos.gtt_qty or 0) == int(pos.quantity)
                and abs(float(pos.gtt_at or 0.0) - float(pos.stop_price or 0.0)) < 0.05
            ),
            "gtt_id": int(pos.gtt_id or 0),
            "gtt_at": float(pos.gtt_at or 0.0),
            "broker_stop_qty": int(pos.gtt_qty or 0),
            "stop_mode": pos.stop_mode,
        })
    return {"positions": rows, "realised_pnl_today": realised_pnl_today(uid)}


@router.get("/adaptive-edge/evidence")
async def adaptive_edge_evidence(user: UserContext = Depends(get_current_user)) -> dict:
    """What the engine has measured live, and whether it has earned the right to trade.

    The implied-to-realised ratio is the fact every offline study of this
    strategy was missing — no store here holds option price history. The engine
    records it every scan, traded or not, and this reports the accumulated
    result plus what is still outstanding before the gate can open.
    """
    uid = getattr(user, "user_id", None) or getattr(user, "uid", None)
    if not uid:
        raise HTTPException(status_code=401, detail="authenticated user is required")
    from app.services.adaptive_edge_evidence import summary
    return summary(uid)


# ------------------------------------------------------------------- Intraday

@router.get("/intraday")
async def get_intraday_config(user: UserContext = Depends(get_current_user)) -> dict:
    """Current config plus the pack's own defaults and vocabularies.

    Published rather than mirrored in the client, for the same reason as every
    other engine here: the recurring bug in this codebase is a UI that claims
    backend behaviour the backend does not honour.

    ``calibrated_fields`` is deliberately EMPTY. Nothing in these three
    strategies has been through the walk-forward harness, and the settings page
    needs that fact to mark each number as a judgement call rather than render a
    bare figure a reader may take for a measurement.
    """
    from app.engines.intraday import (IntradayConfig, PIVOT_PERIODS, PIVOT_TYPES,
                                      STOP_SOURCES, STRATEGY_KEYS, TIMEFRAMES,
                                      TRAIL_MODES, descriptor)
    from app.engines.intraday.config import SIZING_MODES, STOP_MODES
    from app.engines.option_contracts import EXPIRY_SERIES, MONEYNESS
    from app.services.kite_engine.stock_registry import HIGH_LIQUIDITY_STOCK_NAMES
    from app.services.intraday import get_config
    uid = getattr(user, "user_id", None) or getattr(user, "uid", None) or "default"
    cfg = get_config(uid)
    return {
        "strategy": {**descriptor(), "enabled": cfg.enabled},
        "config": cfg.as_dict(),
        "defaults": IntradayConfig().as_dict(),
        "enabled_strategies": list(cfg.enabled_strategies()),
        "vocabularies": {
            "strategy_key": list(STRATEGY_KEYS),
            "timeframe": sorted(TIMEFRAMES),
            "pb_pivot_type": sorted(PIVOT_TYPES),
            "pb_pivot_period": sorted(PIVOT_PERIODS),
            "pb_trail_mode": sorted(TRAIL_MODES),
            "vs_stop_source": sorted(STOP_SOURCES),
            "sizing_mode": sorted(SIZING_MODES),
            "stop_mode": sorted(STOP_MODES),
            "expiry_series_indices": sorted(EXPIRY_SERIES),
            "expiry_series_stocks": sorted(EXPIRY_SERIES),
            "moneyness": sorted(MONEYNESS),
            "scan_stocks": sorted(HIGH_LIQUIDITY_STOCK_NAMES),
        },
        "warnings": cfg.warnings(),
    }


@router.put("/intraday")
async def update_intraday_config(body: dict = Body(...),
                                 user: UserContext = Depends(get_current_user)) -> dict:
    """Apply a partial config change.

    Unknown keys are refused rather than ignored: a silently dropped setting is
    worse than a 422, because the UI has no way to tell that it did not take.
    """
    from app.services.intraday import set_config
    uid = getattr(user, "user_id", None) or getattr(user, "uid", None) or "default"
    values = {k: v for k, v in dict(body).items() if v is not None}
    if not values:
        raise HTTPException(status_code=422, detail="no settings to change")
    try:
        cfg = set_config(values, uid)
    except (ValueError, TypeError) as exc:
        raise HTTPException(status_code=422, detail=str(exc)) from exc
    return {"config": cfg.as_dict(), "warnings": cfg.warnings()}


@router.get("/intraday/snapshot")
async def intraday_snapshot(user: UserContext = Depends(get_current_user)) -> dict:
    """Config, what the last scan found, and every reason nothing is armed."""
    uid = getattr(user, "user_id", None) or getattr(user, "uid", None)
    if not uid:
        raise HTTPException(status_code=401, detail="authenticated user is required")
    from app.services.simulation import simulation_runner
    if simulation_runner.owns_session(uid):
        return simulation_runner.get_intraday_snapshot()
    from app.services.intraday import snapshot
    return snapshot(uid)


@router.post("/intraday/scan")
async def intraday_scan(user: UserContext = Depends(get_current_user)) -> dict:
    """Retired release surface: no new legacy Intraday signals are originated."""
    uid = _intraday_uid(user)
    _archived_entry_surface("intraday", uid)
    from app.services.intraday import scan_once
    return await scan_once(uid)


def _intraday_uid(user: UserContext) -> str:
    uid = getattr(user, "user_id", None) or getattr(user, "uid", None)
    if not uid:
        raise HTTPException(status_code=401, detail="authenticated user is required")
    return str(uid)


@router.post("/intraday/arm")
async def intraday_arm(body: dict = Body(...),
                       user: UserContext = Depends(get_current_user)) -> dict:
    """Retired release surface: no new legacy Intraday position can be armed."""
    uid = _intraday_uid(user)
    _archived_entry_surface("intraday", uid)
    signal_id = str(body.get("signal_id") or "").strip()
    if not signal_id:
        raise HTTPException(422, "signal_id is required")
    from app.services.intraday_runner import arm
    return await arm(uid, signal_id)


@router.post("/intraday/adopt")
async def intraday_adopt(body: dict = Body(...),
                         user: UserContext = Depends(get_current_user)) -> dict:
    """Take responsibility for a position this engine did not open.

    Protection is placed as part of adopting: a position the engine manages but
    has not protected is the worst of both worlds.
    """
    uid = _intraday_uid(user)
    data = dict(body)
    symbol = str(data.get("symbol") or "").strip()
    try:
        quantity = int(data.get("quantity") or 0)
        entry_price = float(data.get("entry_price") or 0)
    except (TypeError, ValueError) as exc:
        raise HTTPException(status_code=422,
                            detail="quantity and entry_price must be numbers") from exc
    if not symbol or quantity <= 0 or entry_price <= 0:
        raise HTTPException(status_code=422,
                            detail="symbol, a positive quantity and entry_price are required")
    from app.services.intraday_runner import adopt
    return await adopt(uid, symbol, quantity, entry_price)


@router.post("/intraday/exit")
async def intraday_exit(body: dict = Body(...),
                        user: UserContext = Depends(get_current_user)) -> dict:
    """Close one position now.

    Deliberately available whatever the manual/auto setting says: auto gates
    opening, and an operator must always be able to close.
    """
    uid = _intraday_uid(user)
    symbol = str(dict(body).get("symbol") or "").strip()
    if not symbol:
        raise HTTPException(status_code=422, detail="symbol is required")
    from app.services.intraday_runner import exit_one
    return await exit_one(uid, symbol)


@router.post("/intraday/square-off")
async def intraday_square_off(user: UserContext = Depends(get_current_user)) -> dict:
    """Flatten everything this engine holds, now."""
    uid = _intraday_uid(user)
    from app.services.intraday_runner import square_off_all
    return await square_off_all(uid)


@router.post("/intraday/reconcile")
async def intraday_reconcile(user: UserContext = Depends(get_current_user)) -> dict:
    """Re-sync against the broker: close what it no longer holds, re-protect the rest."""
    uid = _intraday_uid(user)
    from app.services.intraday_runner import reconcile
    return await reconcile(uid)


@router.get("/intraday/positions")
async def intraday_positions(user: UserContext = Depends(get_current_user)) -> dict:
    """What this engine is holding, and whether each position has a broker stop."""
    uid = _intraday_uid(user)
    from app.services.intraday_positions import load_record
    from app.services.intraday_runner import positions_view, realised_pnl_today
    from app.services.intraday import ist_today
    return {"positions": positions_view(uid),
            "realised_pnl_today": realised_pnl_today(uid),
            "record": load_record(uid).roll(ist_today().isoformat()).as_dict()}


@router.get("/intraday/validation")
async def intraday_validation(user: UserContext = Depends(get_current_user)) -> dict:
    """What the walk-forward harness found, per strategy.

    Published because it is what gates unattended execution: a reader deciding
    whether to switch AUTO on needs the measurement and the reasons, not a
    boolean. Manual arming is deliberately NOT gated on this — an operator
    taking an unproven setup with their eyes open is their call.
    """
    from app.engines.intraday.walkforward import GATE
    from app.services.intraday_validation import load
    return {"gate": GATE,
            "strategies": {k: v.as_dict() for k, v in load().items()},
            "how_to_measure": "python -m study.intraday_walkforward --record"}


@router.get("/intraday/history")
async def intraday_history(sessions: int = 5,
                           user: UserContext = Depends(get_current_user)) -> dict:
    """What these strategies fired over the last few sessions, from stored bars.

    Works with the market closed, with no broker session, and before any live
    scan has ever run. Every rule in this pack fires on ONE bar, and the live
    scan only evaluates the last closed one — so without this the board is
    blank almost always, and an operator cannot tell a quiet strategy from a
    broken one.
    """
    uid = _intraday_uid(user)
    from app.services.intraday import recent_signals
    rows = recent_signals(uid, sessions=max(1, min(int(sessions), 30)))
    return {"sessions": sessions, "signals": rows, "count": len(rows)}


# ------------------------------------------------------------------- Snapback

def _snapback_uid(user: UserContext) -> str:
    uid = getattr(user, "user_id", None) or getattr(user, "uid", None)
    if not uid:
        raise HTTPException(status_code=401, detail="authenticated user is required")
    return str(uid)


@router.get("/snapback")
async def get_snapback_config(user: UserContext = Depends(get_current_user)) -> dict:
    """Current config, the engine's own defaults, and its vocabularies.

    Published rather than mirrored in the client, for the same reason as every
    other engine here: the recurring bug in this codebase is a UI that claims
    backend behaviour the backend does not honour.

    ``calibrated_fields`` is NOT empty for this engine, unlike the intraday
    pack's. Six of its defaults came out of a measurement and the rest are
    judgement calls, and the settings page needs to be able to tell a reader
    which is which rather than rendering every number with the same authority.
    """
    from app.engines.snapback import (EXIT_MODES, SIZING_MODES, SnapbackConfig,
                                      STOP_MODES, VRP_BAND, descriptor)
    from app.engines.option_contracts import EXPIRY_SERIES, INDEX_NAMES, STOCK_NAMES
    from app.services.snapback import get_config
    uid = getattr(user, "user_id", None) or getattr(user, "uid", None) or "default"
    cfg = get_config(uid)
    return {
        "strategy": {**descriptor(cfg), "enabled": cfg.enabled},
        "config": cfg.as_dict(),
        "defaults": SnapbackConfig().as_dict(),
        "vocabularies": {
            "trading_mode": ["swing", "scalp", "intraday", "ultra_scalping", "overnight"],
            "scalp_timeframe_minutes": [1, 3, 5, 15, 30, 60],
            "exit_mode": sorted(EXIT_MODES),
            "sizing_mode": sorted(SIZING_MODES),
            "stop_mode": sorted(STOP_MODES),
            "expiry_series_indices": sorted(EXPIRY_SERIES),
            "expiry_series_stocks": sorted(EXPIRY_SERIES),
            "scan_indices": sorted(INDEX_NAMES),
            "scan_stocks": sorted(STOCK_NAMES),
        },
        "vrp_band": list(VRP_BAND),
        "warnings": cfg.warnings(),
    }


@router.put("/snapback")
async def update_snapback_config(body: dict = Body(...),
                                 user: UserContext = Depends(get_current_user)) -> dict:
    """Apply a partial config change.

    Unknown keys are refused rather than ignored: a silently dropped setting is
    worse than a 422, because the UI has no way to tell that it did not take.
    """
    from app.services.snapback import FrozenExperimentConfigError, set_config
    uid = getattr(user, "user_id", None) or getattr(user, "uid", None) or "default"
    values = {k: v for k, v in dict(body).items() if v is not None}
    if not values:
        raise HTTPException(status_code=422, detail="no settings to change")
    try:
        cfg = set_config(values, uid)
    except FrozenExperimentConfigError as exc:
        # The hypothesis is frozen while evidence is being collected. Operational
        # control is STOP NEW TRADES, which does not touch the strategy.
        raise HTTPException(
            status_code=409,
            detail={"code": "SNAPBACK_CONFIG_FROZEN", "message": str(exc)},
        ) from exc
    except (ValueError, TypeError) as exc:
        raise HTTPException(status_code=422, detail=str(exc)) from exc
    return {"config": cfg.as_dict(), "warnings": cfg.warnings()}


@router.get("/snapback/snapshot")
async def snapback_snapshot(user: UserContext = Depends(get_current_user)) -> dict:
    """Config, what the last scan found, and every reason nothing is armed."""
    from app.services.simulation import simulation_runner
    uid = _snapback_uid(user)
    if simulation_runner.has_session_view and getattr(simulation_runner, '_uid', None) == uid:
        return simulation_runner.get_snapback_snapshot()
    from app.services.snapback import snapshot
    return snapshot(uid)


@router.post("/snapback/scan")
async def snapback_scan(body: Optional[dict] = Body(None), user: UserContext = Depends(get_current_user)) -> dict:
    """Run one universe -> daily candles -> signals pass.

    Worth running after the close and before the open, not every few minutes:
    every rule in this engine is stated on a daily CLOSE, so nothing it watches
    can change intraday.
    """
    from app.services.snapback import scan_modes
    modes = body.get("modes") if body else None
    if modes is not None and (not isinstance(modes, list) or not modes or len(modes)>5 or any(m not in ("swing", "scalp", "intraday", "ultra_scalping", "overnight") for m in modes)):
        raise HTTPException(422, "Choose one or more supported scan modes")
    try:
        return await scan_modes(_snapback_uid(user), modes)
    except Exception as exc:
        raise HTTPException(status_code=502,
                            detail=f"Snapback scan failed: {exc}") from exc


@router.post("/snapback/scan/stop")
async def snapback_stop_scan(user: UserContext = Depends(get_current_user)) -> dict:
    from app.services.snapback import stop_scan
    return await stop_scan(_snapback_uid(user))


@router.get("/snapback/validation")
async def snapback_validation(user: UserContext = Depends(get_current_user)) -> dict:
    """What the walk-forward harness found, and what it therefore permits.

    The record carries the checks that PASSED as well as the verdict. This
    engine clears seven of nine — including the entry-timing permutation that
    every other strategy in this repo has failed, the priced-edge check at a
    break-even vol multiple of 2.22 against a market charging 1.15-1.30, and the
    day-clustered interval that nothing here has ever cleared — and misses on
    the deflated Sharpe and a year-consistency bar. A bare "not
    promoted" would read identically to a strategy whose entries lose money, and
    those are not the same thing to an operator deciding whether to arm one by
    hand.
    """
    from app.services.snapback_validation import (auto_execution_blocker,
                                                  evidence_advisory, load)
    from app.services.snapback import get_config
    cfg = get_config(_snapback_uid(user))
    if cfg.trading_mode != "swing":
        return {"record": {}, "auto_execution_blocker": auto_execution_blocker(cfg),
                "evidence_advisory": evidence_advisory(cfg),
                "how_to_measure": "Replay synchronized real option candles via "
                                  "/api/v1/config/snapback/replay-intraday; "
                                  "daily evidence cannot promote intraday modes"}
    return {"record": load(), "auto_execution_blocker": auto_execution_blocker(cfg),
            "evidence_advisory": evidence_advisory(cfg),
            "how_to_measure": "python -m study.snapback_research --part gate --record"}


@router.get("/snapback/readiness")
async def snapback_readiness(user: UserContext = Depends(get_current_user)) -> dict:
    """Whether Snapback can open live risk right now, and exactly what stops it.

    Every field is derived from live state: the kill switch, safe mode, the
    control-plane recovery state, unresolved orders, the daily-loss halt, foreign
    broker exposure, runtime health and reconciliation, the lane's origination
    rule, the session, and the configuration itself. ``blockers`` carries short
    reason codes; ``blocker_text`` the same in plain words.
    """
    from app.services.snapback import get_config, status
    from app.services.snapback_readiness import live_conditions, reason_text
    from app.services.snapback_validation import auto_execution_blocker, evidence_advisory
    from app.services.snapback_plan_producer import unsupported_config_reasons
    uid = _snapback_uid(user)
    cfg = get_config(uid)
    st = status(uid)
    cond = live_conditions(uid, cfg)
    config_reasons = unsupported_config_reasons(cfg)

    codes = [*config_reasons, *cond.blockers]
    eligible = not codes
    if not cfg.enabled:
        mode = "OFF"
    elif not eligible:
        mode = "BLOCKED"
    elif cfg.auto_execute and not cond.auto_off:
        mode = "LIVE_AUTO"
    else:
        mode = "LIVE_MANUAL"

    return {
        "trading_mode": cfg.trading_mode,
        "operational_mode": mode,
        "config_generation": getattr(st, "config_generation", 0),
        "is_live_eligible": eligible,
        "manual_eligible_now": eligible and not cond.session,
        "auto_enabled": bool(cfg.auto_execute) and not cond.auto_off,
        "blockers": codes,
        "blocker_text": [reason_text(c) for c in codes],
        "session": list(cond.session),
        "auto_execution_blocker": auto_execution_blocker(cfg),
        "evidence_advisory": evidence_advisory(cfg),
        "supported_scope": {
            "max_lots": int(cfg.max_lots),
            "max_risk_pct": cfg.scalp_risk_pct,
            "max_daily_loss_pct": cfg.scalp_daily_loss_pct,
            "universe_mode": cfg.universe_mode,
        },
    }


@router.get("/snapback/live")
async def snapback_live(user: UserContext = Depends(get_current_user)) -> dict:
    """The live book and the dispatcher: open positions, their stops, and what the
    last dispatch cycle decided."""
    from app.services import snapback_live_positions
    from app.services.snapback_dispatcher import get_dispatcher
    uid = _snapback_uid(user)
    store = snapback_live_positions.default_store()
    return {
        "dispatcher": get_dispatcher().status(uid),
        "open": [p.as_dict() for p in store.open_positions(uid)],
        "recent": [p.as_dict() for p in store.list(uid, statuses=[snapback_live_positions.CLOSED])[-20:]],
    }


@router.get("/snapback/positions")
async def snapback_positions(user: UserContext = Depends(get_current_user)) -> dict:
    """Current Snapback intraday/scalp position state machine projections."""
    from app.services.snapback import status
    uid = _snapback_uid(user)
    st = status(uid)
    return {
        "positions": getattr(st, "active_positions", []),
        "count": len(getattr(st, "active_positions", [])),
    }


@router.get("/snapback/history")
async def snapback_history(sessions: int = 30,
                           user: UserContext = Depends(get_current_user)) -> dict:
    """What this engine fired over the last few weeks, from stored daily bars.

    Works with the market closed, with no broker session, and before any live
    scan has ever run. Every rule in this engine fires on ONE session and the
    live scan only evaluates the last three — so without this the board is blank
    almost always, and an operator cannot tell a quiet strategy from a broken
    one. That is a bug this repo has already had to fix once, in the intraday
    pack.
    """
    from app.services.snapback import recent_signals
    rows = recent_signals(_snapback_uid(user),
                          sessions=max(1, min(int(sessions), 180)))
    return {"sessions": sessions, "signals": rows, "count": len(rows)}


class SnapbackReplayCandle(BaseModel):
    """Strict caller-supplied candle; time is its opening epoch in seconds."""
    model_config = ConfigDict(extra="forbid", allow_inf_nan=False)
    time: float
    open: float = Field(gt=0)
    high: float = Field(gt=0)
    low: float = Field(gt=0)
    close: float = Field(gt=0)
    volume: float = Field(default=0, ge=0)


class SnapbackIntradayReplayRequest(BaseModel):
    model_config = ConfigDict(extra="forbid")
    symbol: str = Field(min_length=1, max_length=64)
    option_symbol: str = Field(min_length=1, max_length=100)
    option_type: Literal["CE", "PE"]
    lot_size: int = Field(gt=0, le=100_000, strict=True)
    underlying: list[SnapbackReplayCandle] = Field(min_length=1, max_length=10_000)
    option_candles: list[SnapbackReplayCandle] = Field(min_length=1, max_length=10_000)
    settings: dict[str, Any] = Field(default_factory=dict)


@router.post("/snapback/replay-intraday")
def snapback_replay_intraday(body: SnapbackIntradayReplayRequest,
                            user: UserContext = Depends(get_current_user)) -> dict:
    """Research-only replay; does not save settings or place broker orders."""
    import numpy as np
    from app.engines.snapback import Bars, validate
    from app.engines.snapback.intraday import replay_intraday
    from app.services.snapback import get_config

    def columns(candles):
        # Do not use the tolerant live parser here: dropping a malformed or
        # duplicate bar changes a financial replay's sample without disclosure.
        return Bars(*(np.asarray([getattr(c, key) for c in candles], dtype=float)
                      for key in ("time", "open", "high", "low", "close", "volume")))

    try:
        cfg = validate(body.settings, base=get_config(_snapback_uid(user)))
        result = replay_intraday(columns(body.underlying), columns(body.option_candles), cfg,
                                 body.symbol, option_type=body.option_type,
                                 lot_size=body.lot_size, option_symbol=body.option_symbol)
    except (TypeError, ValueError, OverflowError) as exc:
        raise HTTPException(status_code=422, detail=str(exc)) from exc
    return {**result, "data_source": "Caller-supplied candles; provenance is not independently verified",
            "config": cfg.as_dict()}


@router.get('/shared-risk')
def get_shared_risk(user: UserContext = Depends(get_current_user)) -> dict:
    from app.services.shared_risk import get_config
    try:
        return get_config(user.user_id).model_dump()
    except Exception as exc:
        raise HTTPException(status_code=503,detail='Shared risk settings unavailable') from exc


@router.put('/shared-risk')
def put_shared_risk(body: dict = Body(...),user: UserContext = Depends(get_current_user)) -> dict:
    from pydantic import ValidationError
    from app.services.shared_risk import SharedRiskConfig,save_config,RevisionConflict
    try:
        cfg=SharedRiskConfig.model_validate(body)
        return save_config(user.user_id,cfg).model_dump()
    except RevisionConflict as exc:
        raise HTTPException(status_code=409,detail=str(exc)) from exc
    except (ValidationError,ValueError) as exc:
        raise HTTPException(status_code=422,detail=str(exc)) from exc
    except Exception as exc:
        raise HTTPException(status_code=503,detail='Shared risk settings could not be saved') from exc
